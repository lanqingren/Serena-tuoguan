Serena uses (modified) versions of other libraries/packages:

 * solidlsp (our fork of [microsoft/multilspy](https://github.com/microsoft/multilspy) for fully synchronous language server communication)
 * [interprompt](https://github.com/oraios/interprompt) (our prompt templating library)
