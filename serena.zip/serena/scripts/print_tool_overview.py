from serena.agent import ToolRegistry

if __name__ == "__main__":
    ToolRegistry().print_tool_overview()
