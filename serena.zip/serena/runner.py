# runner.py: 一个健壮的启动器脚本，用于在有问题的云环境中执行命令

import subprocess
import sys

def main():
    """
    此脚本的唯一任务是使用正确的方式，
    执行 Serena 官方指定的 `serena-mcp-server` 命令。
    """
    # 这是我们真正需要执行的、由 Serena 库提供的官方命令
    command_to_run = ["serena-mcp-server"]
    
    print(f"--- [启动脚本] 准备执行: {' '.join(command_to_run)} ---")
    
    try:
        # 使用 Python 的标准 subprocess 模块来执行命令，
        # 它可以保证命令和参数被正确地传递给操作系统。
        result = subprocess.run(command_to_run, check=True)
        # 如果命令成功，脚本会以相同的状态码退出
        sys.exit(result.returncode)
        
    except FileNotFoundError:
        print("!!! [启动脚本错误] !!!")
        print("命令 'serena-mcp-server' 未找到。")
        print("请确认 'requirements.txt' 文件是否正确配置并且被平台成功安装。")
        sys.exit(1)
        
    except Exception as e:
        # 捕获其他可能的执行错误
        print(f"!!! [启动脚本错误] 执行命令时发生未知错误: {e} !!!")
        sys.exit(1)

if __name__ == "__main__":
    main()