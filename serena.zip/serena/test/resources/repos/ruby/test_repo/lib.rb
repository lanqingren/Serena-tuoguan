class Calculator
  def add(a, b)
    a + b
  end

  def subtract(a, b)
    a - b
  end
end
