package test_repo

object ModelUser {
    @JvmStatic
    fun main(args: Array<String>) {
        val model = Model("Cascade")
        println(model.name)
    }
}