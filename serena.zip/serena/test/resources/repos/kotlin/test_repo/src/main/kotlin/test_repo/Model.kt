package test_repo

data class Model(val name: String)