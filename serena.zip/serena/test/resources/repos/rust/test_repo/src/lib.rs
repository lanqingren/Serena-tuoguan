// This function returns the sum of 2 + 2
pub fn add() -> i32 {
    let res = 2 + 2;
    res
}
pub fn multiply() -> i32 {
    2 * 3
}

